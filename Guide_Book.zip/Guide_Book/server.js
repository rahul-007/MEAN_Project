var express=require('express');
var bodyParser = require('body-parser');
var app=express();
var MongoClient = require('mongodb').MongoClient;

var url="mongodb://localhost:27017/test";

app.use(bodyParser.json()); 
app.use(bodyParser.urlencoded({ extended: true }));

app.post("/editangulardata",function(req,res){
  console.log('find running');
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, POST");
  var jsondata=JSON.parse(req.body.mydata);
  console.log('*8*' +jsondata.title);
  MongoClient.connect(url,function(err,db){
  if(err){
  console.log('unable to connect.Error is :',err);
  }else{
  var result=[];
  var collection=db.collection('nsndata1');
  collection.deleteOne({id:jsondata.id},function(err,data){
    if(err){
      console.log('Error is :',err);
    }else{
      console.log(jsondata.title);
    }
  });

  var e2={id:jsondata.id,title:jsondata.title,summary:jsondata.summary};
  collection.insert(e2,function(err,data){
    if(err){
      console.log('Error is :',err);
    }else{
      res.send('data inserted successfully...');
    }
    db.close();
  });
  }

});

});

app.post('/deleteangulardata', function (req, res){
        res.header("Access-Control-Allow-Origin", "*");
        res.header("Access-Control-Allow-Methods", "GET, POST");
        var jsondata=JSON.parse(req.body.mydata);
        MongoClient.connect(url,function(err,db){
if(err){
  console.log('unable to connect.Error is :',err);
}else{
  var collection=db.collection('nsndata1');
  collection.deleteOne({title:jsondata.title},function(err,data){
    if(err){
      console.log('Error is :',err);
    }else{
        res.send('data deleted');
      console.log(jsondata.title);
    }
    db.close();
  });
}

});

});

app.post('/insertangularmongouser', function (req, res){
    //  res.header("Access-Control-Allow-Headers: accept, content-type");
    //   res.header("Access-Control-Request-Headers: X-Requested-With, accept, content-type");
       res.header("Access-Control-Allow-Origin", "*");
        res.header("Access-Control-Allow-Methods", "GET, POST");
      console.log(req.body.mydata);
      var jsondata=JSON.parse(req.body.mydata);
      MongoClient.connect(url,function(err,db){
if(err){
	console.log('unable to connect.Error is :',err);
}else{
	var collection=db.collection('nsndata1');
	//var e1={Title:'life after Life',Author:'Rahul Sarkar'};
	var e2={id:jsondata.id,title:jsondata.title,summary:jsondata.summary};
	collection.insert(e2,function(err,data){
		if(err){
			console.log('Error is :',err);
		}else{
			res.send('data inserted successfully...');
		}
		db.close();
	});
}

});
});

app.get('/getangularusers',function(req,res){
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, POST");
 //   res.send('Our Sample API is up...');
  //  var user_id=req.param('id');
  //  res.send(user_id);
  var str="";
  var result = [];
  var MongoClient = require('mongodb').MongoClient;

var url="mongodb://localhost:27017/test";

MongoClient.connect(url,function(err,db){
if(err){
  console.log('unable to connect.Error is :',err);
}else{
  var collection=db.collection('nsndata1');
  collection.find().toArray(function(err,data){
    if(err){
      console.log('Error is : ',err);
    }else{
      for(var i=0;i<data.length;i++){
    //   str += data[i].Title + ":" + data[i].Author;
        result.push({id: data[i].id, title: data[i].title, summary: data[i].summary});
    //   console.log(str);
      }
    }
    res.setHeader('Content-Type', 'application/json');
    res.send(JSON.stringify(result));
    console.log(JSON.stringify(result));
    db.close();
  });
}

});

});

app.post('/api/users', function(req, res) {
    var user_name = req.body.user;
    var password = req.body.password;
    res.send(user_name + ' ' + password);
});



app.listen(3000, function () {
  console.log('Example app listening on port 3000!');
});

