'use strict';

var app = angular.module("myapp",['ngRoute']);

app.config(['$httpProvider', function($httpProvider) {
     $httpProvider.defaults.useXDomain = true;
     delete $httpProvider.defaults.headers.common['X-Requested-With'];
   }
]);

app.config(function($routeProvider){
 $routeProvider.when('/', {
   controller: 'introcon',
    templateUrl: 'partials/index.html'

}).when('/viewchapter', {
   controller: 'viewcon',
    templateUrl: 'partials/viewchapter.html'

}).when('/delete/:title', {
   controller: 'delcon',
    templateUrl: 'partials/viewchapter.html'

}).when('/editview/:id/:title/:summary', {
   controller: 'editviewcon',
    templateUrl: 'partials/editview.html'

}).when('/addchapter', {
   controller: 'addcon',
    templateUrl: 'partials/addchapter.html'

});


});

app.controller('maincon',function($scope,$location){
   $scope.startsearch=function(){
      $location.path('/viewchapter');
};
});

app.controller('addcon',function($scope,myservice,$http,$templateCache) {
  $scope.data=null;
  $scope.fun=function(){
  var formdata={
     'id' : $scope.data.id,
     'title':$scope.data.title,
     'summary':$scope.data.summary
    };
  var jdata='mydata='+JSON.stringify(formdata);
  $http({
    method:'POST',
    url:'http://localhost:3000/insertangularmongouser',
    data:jdata,
    headers:{'Content-Type': 'application/x-www-form-urlencoded'},
    cache:$templateCache
  }).success(function(response){
    console.log('success');
  }).error(function(response){
    console.log('error');
  });
 // myservice.save($scope.data);
  $scope.data=null;
  };
  
});

app.controller('editviewcon',function($scope,$timeout,$routeParams,$http,$templateCache) {
  $scope.data={id:$routeParams.id,title:$routeParams.title,summary:$routeParams.summary};
  
  $scope.fun=function(){
   var formdata={
     'id':$scope.data.id,
     'title':$scope.data.title,
     'summary':$scope.data.summary
    };
  var jdata='mydata='+JSON.stringify(formdata);
  $http({
    method:'POST',
    url:'http://localhost:3000/editangulardata',
    data:jdata,
    headers:{'Content-Type': 'application/x-www-form-urlencoded'},
    cache:$templateCache
  }).success(function(response){
    console.log('success');
  }).error(function(response){
    console.log('error');
  });
   $scope.data=null;
  };

});

app.controller('delcon',function($scope,$timeout,$routeParams,$http,$templateCache) {
//  myservice.del($routeParams.id);

  var title=$routeParams.title;
  var formdata={
     'title':title
    };
  var jdata='mydata='+JSON.stringify(formdata);
  $http({
    method:'POST',
    url:'http://localhost:3000/deleteangulardata',
    data:jdata,
    headers:{'Content-Type': 'application/x-www-form-urlencoded'},
    cache:$templateCache
  }).success(function(response){
    console.log('success');
  }).error(function(response){
    console.log('error');
  });

   $timeout(function () {}, 2000);

  $http.get('http://localhost:3000/getangularusers').success(function(data){
    $scope.data=data;
    console.log('success');
  }).error(function(data){
    console.log('error occured ');
  });
 // $scope.data=myservice.get();
});

app.service('myservice',function(){

var data= [{
      id: 0,
      title: 'Chapter 1: So, What is AngularJS?',
      summary: 'Find out what separates AngularJS from...'
    }, {
      id: 1,
      title: 'Chapter 2: HelloWorld',
      summary: 'Learn how to get up and running with...'
    }, {
      id: 2,
      title: 'Chapter 3: QuickStart',
      summary: 'Brush up on the Model-View-Controller...'
    }, {
      id: 3,
      title: 'Chapter 4: Key AngularJS Features',
      summary: 'Discover the strengths of AngularJS...'
    }, {
      id: 4,
      title: 'Chapter 5: The AngularJS Community',
      summary: 'Get to know the top contributors...'
    }
    ];

var title="This app has been designed for a guidebook where you can read/delete any chapters depending on your choice.Hope you all like it!!!";

this.update=function(x){
   var i;
   for(i=0;i<data.length;i++){
   if(data[i].id==parseInt(x.id))
   break;
   }
   data[i]=x;
};

this.save=function(x){
    data.push(x);
};

this.getdata=function(id){
    return data[id];
};

this.del=function(id){
    data.splice(id,1);
};

this.getTitle=function(){
   return title;
};

this.get=function(){
  return data; 
};

});


app.controller('introcon',function($scope,myservice) {
  
  $scope.disp=myservice.getTitle();
});

app.controller('viewcon',function($scope,myservice,$http) {
 // $scope.data=myservice.get();
  $http.get('http://localhost:3000/getangularusers').success(function(data){
    $scope.data=data;
    console.log('success');
  }).error(function(data){
    console.log('error occured ');
  });
});
